/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetotrycatch;

import javax.swing.JOptionPane;

/**
 *
 * @author arthur.plima2
 */
public class Projetotrycatch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       /*int valor = 5;
       int valor2 = 0;
       try{
           
          int resultado = valor/valor2;
          System.out.println("o resultado e" + resultado);
          }catch(ArithmeticException e){
           System.out.println("divisao por zero");
          }*/
       String idadeTexto = JOptionPane.showInputDialog("Digite sua idade(apenas numeros");
       try{
           
           int idade = Integer.parseInt(idadeTexto);
           JOptionPane.showMessageDialog(null, "sua idade e " + idade + " anos ");
       }catch(NumberFormatException e){
        JOptionPane.showMessageDialog(null,
           "Erro de Processo: Por favor, digite apenas numeros inteiros validos",
           "Erro de entrada", JOptionPane.ERROR_MESSAGE);
        
       }
       System.out.println("Processo de idade finalizado");
       }
}
